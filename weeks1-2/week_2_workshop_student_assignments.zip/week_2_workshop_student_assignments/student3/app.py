from banking_pkg.account import show_balance, deposit, withdraw, logout


def atm_menu(name):
    print("")
    print("          === Automated Teller Machine ===          ")
    print("User: " + name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")


# Task 2 - Input name and pin
print("          === Automated Teller Machine ===          ")
while True:
    name = input("Enter name to register: ")
    if len(name) > 10:
        print("Please enter a name of 1 - 10 characters only")
    else:
        break
while True:
    pin = input("Enter PIN: ")
    if len(pin) > 4 or len(pin) <= 1:
        print("PIN must contain 4 numbers")
    else:
        break
balance = 0
print(f"{name} has been registered with a starting balance of ${balance}")
name_to_validate = name
pin_to_validate = pin

while True:
    print("          === Automated Teller Machine ===          ")
    print("LOGIN")
    name = input("Enter name to login: ")
    pin = input("Enter PIN: ")
    balance = 0
    if name == name_to_validate and pin_to_validate == pin:
        print('Login successful')
        break
    else:
        print("Invalid credentials!")
        continue
while True:
    atm_menu(name)
    option = input("Choose an option:")
    if option == '1':
        print("")
        print("")
        show_balance(balance)
    elif option == '2':
        balance = deposit(balance)
        print(f'Your new balance is ${balance}')
    elif option == '3':
        balance = withdraw(balance)
        print(f'Your new balance is ${balance}')
    elif option == '4':
        logout(name)
        break
    else:
        print('\nInvalid option, please try again.')
        continue
