def show_balance(balance):
    print(f'Your current balance is ${float(balance)}')


def deposit(balance):
    # print(float(balance))
    amount = input("Enter amount to deposit: ")
    return (balance + int(amount))


def withdraw(balance):
    print(f'\nYour  current balance is ${float(balance)}')
    withdraw_amt = input("Enter amount to withrdraw: ")
    return (balance - float(withdraw_amt))


def logout(name):
    print(f"Goodbye {name}!")
