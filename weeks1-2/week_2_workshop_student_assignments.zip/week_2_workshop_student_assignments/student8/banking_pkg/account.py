

def show_balance(balance):
    print(f"Current Balance is : ${balance}")
    return balance


def deposit(balance):
    amount = float(input("Enter amount to deposit : "))
    result = balance + amount
    print(f"Current Balance is:  ${result}")
    return result


def withdraw(balance):
    amount = float(input("Enter amount to withdraw : "))
    result = balance - amount
    print(f"Current Balance is:  {result}")
    return result


def logout(user_name):
    print(f"Goodbye {user_name}!")
