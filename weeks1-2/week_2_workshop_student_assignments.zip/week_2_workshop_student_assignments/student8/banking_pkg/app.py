from banking_pkg import account


def atm_menu(_name):

    print("")
    print("          === Automated Teller Machine ===          ")
    print("User: " + _name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")


print("          === Automated Teller Machine ===          ")
in_name = input("Enter name to register: ")
in_pin = input("Enter PIN: ")
balance = 0
print(f"{in_name} has been registered with a starting balance of ${balance}")

while (True):
    print("\nLOGIN")
    user_name = input("Enter name: ")
    password = input("Enter PIN: ")
    if user_name != in_name or password != in_pin:
        print("Invalid credentials!")
    elif user_name == in_name and password == in_pin:
        print("Login successful!")
        break

while (True):
    atm_menu(user_name)
    option = input("Choose an option: ")
    if option in ("1", "Balance", "balance"):
        balance = account.show_balance(balance)

    elif option in ("2", "Deposit", "deposit"):
        balance = account.deposit(balance)

    elif option in ("3", "Withdraw", "withdraw"):
        balance = account.withdraw(balance)

    elif option in ("4", "Logout", "logout"):
        account.logout(user_name)
