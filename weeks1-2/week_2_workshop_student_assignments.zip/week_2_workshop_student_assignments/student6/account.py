def Show_balance( balance ): 
    print( float(balance))


def deposit( balance ):
    print(float(balance))
    amount = input ("Enter Amount to Deposit: ")
    return (balance + int(amount))


def withdraw ( balance):
    print(float(balance))
    withdraw_amt = input("Enter amount to withdraw: ")
    return (balance - float (withdraw_amt))

def logout ( name):
print "Goodbye {name}!")
