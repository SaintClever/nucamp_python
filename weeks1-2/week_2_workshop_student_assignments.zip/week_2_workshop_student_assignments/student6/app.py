from workshop2.banking_pkg.account import logout, withdraw
from banking_pkg.account import Show_balance,deposit

def atm_menu(name):
    print("")
    print("          === Automated Teller Machine ===          ")
    print("User: " + name)
    print("------------------------------------------")
    print("| 1.    Balance     | 2.    Deposit      |")
    print("------------------------------------------")
    print("------------------------------------------")
    print("| 3.    Withdraw    | 4.    Logout       |")
    print("------------------------------------------")

    print("          === Automated Teller Machine ===           ")
    
name = input("Enter name to register: ")
pin = input("Enter PIN")
balance = 0
print(f" {name} has been has been registered with a starting balance of ${ balance } ")

name_to_validate = name 
pin_to_validate = pin

while True:
    print("           === Automated Teller Machine ===          ")
    print("LOGIN")
    name = input ("Enter name to register: ")
    pin = input ("Enter PIN: ")
    balance = 0 
    print
    if name == name_to_validate and pin_to_validate == pin:
        print ('Login Successfull')
        break
    else: 
        print("invalid credentials!")
        continue
while True: 
    atm_menu = (name)
    option = input ("choose an option: ")
    if option == '1':
        Show_balance (balance)
    elif option == '2':
        balance = deposit(balance)
        print(F' Your new balance is {balance})')
    else:
        break
    if option == '3':
         balance = withdraw (balance)
         print=(F' Amount to withdraw')
    elif option == '4':
         logout(name):
         break
